# -*- coding: utf-8 -*-
# @Date    : 2017-08-02 21:54:08
# @Author  : lileilei
from Public.fengzhuang_dict import res
from .log import LOG, logger
import  json

@logger('断言测试结果')
def assert_in(asserqiwang, actulval):
    '''
    通过 冒号去隔断,找出实际返回的json里面的key,value个数和期望的json里面key value进行比较
    '''
    actulval=json.loads(actulval)
    excpval = json.loads(asserqiwang)
    if len(asserqiwang.split(':')) > 1:

        print(type(actulval))
        print(type(excpval))

        for item in excpval.keys():
            if item in actulval.keys():
                '''判断值是否正确'''
                if actulval.get(item) in excpval.get(item):
                    continue
                else:
                    LOG.error(
                        '当前匹配的参数key:%s,和实际返回的value:%s,预期valu:%s 不一致' % (item, actulval.get(item), excpval.get(item)))
                    return False
            else:

                LOG.error(
                    '缺少对用key值:%s >>>>>当前匹配的参数key:%s,在预期返回的json字符串里面找不到对应的key'% item)
                return False


@logger('断言测试结果')
def assertre(asserqingwang):
    if len(asserqingwang.split('=')) > 1:
        data = asserqingwang.split('&')
        result = dict([(item.split('=')) for item in data])
        return result
    else:
        LOG.info('填写测试预期值')
        raise {"statecode": 1, 'result': '填写测试预期值'}
