import requests

from Public.log import logger
from config.config_T import UserName,PassWord,LoginUrl,TestPlanUrl


@logger('登录接口')
class Login:


    def login(self):
        '''
        登录方式 获取后续接口传参需要得token之类得校验的等等
        '''
        url=TestPlanUrl+LoginUrl
        payload = "{'email':'%s','password':'%s'}"%(UserName,PassWord)
        headers = {
            'Content-Type': 'application/json;charset=utf-8'

        }

        response = requests.request("POST", url=TestPlanUrl+LoginUrl, headers=headers, data=payload)

        return response.text



print(Login().login())