""" 

"""
Dingtalk_access_token = ""  # 钉钉配置
TestPlanUrl = 'https://perfdog.qq.com'  # 基础url
Config_Try_Num = 3  # 失败重试
UserName='huangshaobo@codemao.cn'
PassWord='x9161635:1$'
LoginUrl='/account/email/login'