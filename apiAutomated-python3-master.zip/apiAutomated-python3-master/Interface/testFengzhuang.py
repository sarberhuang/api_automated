# -*- coding: utf-8 -*-
import requests

from Public.test_requests import requ

reques = requ()


class TestApi(object):
    def __init__(self, url, key, connent, fangshi):
        self.url = url
        self.key = key
        self.connent = connent
        self.fangshi = fangshi

    def testapi(self):
        if self.fangshi == 'POST' or self.fangshi == 'post':
            self.parem = {'key': self.key, 'info': self.connent}
            self.response = reques.post(self.url, self.parem)
        elif self.fangshi == "GET" or self.fangshi == 'get':
            self.parem = {'key': self.key, 'info': self.connent}
            self.response = reques.get(url=self.url, params=self.parem)
        return self.response

    def getJson(self):
        json_data = self.testapi()
        return json_data

    def getstatecode(self):
        statecode= requests.get(self.url).status_code
        return statecode
